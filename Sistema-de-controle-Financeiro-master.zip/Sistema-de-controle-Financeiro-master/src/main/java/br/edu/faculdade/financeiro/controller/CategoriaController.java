package br.edu.faculdade.financeiro.controller;
import java.net.URI;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.edu.faculdade.financeiro.dto.CategoriaRequest;
import br.edu.faculdade.financeiro.dto.CategoriaResponse;
import br.edu.faculdade.financeiro.service.CategoriaService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController @RequestMapping("/api/categorias")
@SecurityRequirement(name = "bearerAuth")
public class CategoriaController {
    private final CategoriaService service;
    public CategoriaController(CategoriaService service) { this.service=service; }
    @PostMapping public ResponseEntity<CategoriaResponse> criar(@Valid @RequestBody CategoriaRequest r) {
        var criado=service.criar(r); return ResponseEntity.created(URI.create("/api/categorias/"+criado.id())).body(criado);
    }
    @GetMapping public List<CategoriaResponse> listar() { return service.listar(); }
    @GetMapping("/{id}") public CategoriaResponse obter(@PathVariable Long id) { return service.obter(id); }
    @PutMapping("/{id}") public CategoriaResponse atualizar(@PathVariable Long id,@Valid @RequestBody CategoriaRequest r) { return service.atualizar(id,r); }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void excluir(@PathVariable Long id) { service.excluir(id); }
}
